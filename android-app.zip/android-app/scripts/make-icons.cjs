// Generates Android launcher icons & splash screens from the brand SVGs.
const fs = require('fs');
const path = require('path');
const sharp = require(process.env.SHARP || 'sharp');
const BRAND = path.join(__dirname, '..', '..', 'brand');
const RES = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'res');
const icon = fs.readFileSync(path.join(BRAND, 'icon.svg'), 'utf8');
const markSvg = fs.readFileSync(path.join(BRAND, 'mark.svg'), 'utf8');
const defs = icon.match(/<defs>[\s\S]*?<\/defs>/)[0];
const markInner = markSvg.replace(/^[\s\S]*?<\/defs>/, '').replace(/<\/svg>\s*$/, '');
// mark geometry lives in the 512 box (x 110..402, y 108..428); centre ≈ (256, 262)
const markAt = (cx, cy, scale) => `<g transform="translate(${cx} ${cy}) scale(${scale}) translate(-256 -262)">${markInner}</g>`;
const bg = `<rect width="100%" height="100%" fill="url(#bg)"/><rect width="100%" height="100%" fill="url(#glow)"/>`;

const D = { mdpi: 1, hdpi: 1.5, xhdpi: 2, xxhdpi: 3, xxxhdpi: 4 };
(async () => {
  for (const [d, k] of Object.entries(D)) {
    const dir = path.join(RES, `mipmap-${d}`);
    const s = Math.round(48 * k);
    await sharp(Buffer.from(icon)).resize(s, s).png().toFile(path.join(dir, 'ic_launcher.png'));
    const round = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">${defs}<clipPath id="c"><circle cx="256" cy="256" r="256"/></clipPath><g clip-path="url(#c)">${bg}</g>${markAt(256, 262, 0.82)}</svg>`;
    await sharp(Buffer.from(round)).resize(s, s).png().toFile(path.join(dir, 'ic_launcher_round.png'));
    const f = Math.round(108 * k);
    // adaptive foreground: keep the mark inside the 66dp safe zone
    const fg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">${defs}${markAt(256, 262, 0.74)}</svg>`;
    await sharp(Buffer.from(fg)).resize(f, f).png().toFile(path.join(dir, 'ic_launcher_foreground.png'));
  }
  fs.writeFileSync(path.join(RES, 'values', 'ic_launcher_background.xml'),
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0F1C3A</color>\n</resources>\n');

  // splash screens: navy field, app icon centred, wordmark below
  const splash = async (file) => {
    const meta = await sharp(file).metadata();
    const { width: w, height: h } = meta;
    const ic = Math.round(Math.min(w, h) * 0.26);
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">${defs.replace('id="bg" x1="0" y1="0" x2="1" y2="1"', 'id="bg" x1="0" y1="0" x2="0" y2="1"')}
      <rect width="100%" height="100%" fill="#0A1328"/><rect width="100%" height="100%" fill="url(#glow)"/>
      <g transform="translate(${(w - ic) / 2} ${(h - ic) / 2 - ic * 0.15}) scale(${ic / 512})">${icon.replace(/^[\s\S]*?<\/defs>/, '').replace(/<\/svg>\s*$/, '')}</g></svg>`;
    await sharp(Buffer.from(svg)).png().toFile(file + '.tmp');
    fs.renameSync(file + '.tmp', file);
  };
  for (const dir of fs.readdirSync(RES).filter((x) => x.startsWith('drawable'))) {
    const f = path.join(RES, dir, 'splash.png');
    if (fs.existsSync(f)) await splash(f);
  }
  console.log('icons & splash generated');
})();
